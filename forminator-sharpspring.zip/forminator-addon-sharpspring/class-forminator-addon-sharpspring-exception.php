<?php

/**
 * Class Forminator_Addon_SharpSpring_Exception
 * Not Required but encouraged
 *
 * @since 1.0 SharpSpring Addon
 */
class Forminator_Addon_SharpSpring_Exception extends Exception {

}
